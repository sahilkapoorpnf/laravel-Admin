<?php $__env->startSection('content'); ?>

<!-- Datatables Header -->
<div class="content-header">
    <div class="header-section">
        <h1>
            <i class="fa fa-table"></i>Booking Management<br><small>You can manage your entire registered bookings!</small>
        </h1>
    </div>
</div>
<ul class="breadcrumb breadcrumb-top">
    <li>Bookings</li>
    <li><a href="<?php echo e(url('admin/manage-bookings')); ?>">Manage Booking</a></li>
</ul>
<!-- END Datatables Header -->

<!-- Datatables Content -->
<div class="block full">
    <div class="block-title">
        <h2><strong>Manage</strong> Bookings</h2>
    </div>

    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>
    <div class="table-responsive">
        <table id="example-datatable" class="table table-vcenter table-condensed table-bordered">
            <thead>
                <tr>
                    <th class="text-center">ID</th>
                    <th>Stylist Name</th>
                    <th>Stylist Email</th>
                    <th>User Name</th>
                    <th>User Email</th>
                    <th>User Phone</th>
                    <th>Booking Title</th>
                    <th>Booking Date</th>
                    <th>Booking Time</th>
                    <th>Booking Location</th>
                    <th>Booking Budget</th>
                    <th>Booking Status</th>
                    <!--<th>Status</th>-->
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1
                ?>
                <?php $__currentLoopData = $all_booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                $encodedUserId = encrypt($allUser->id) ;
                $stylist_data=DB::table('users')->where('id',$allUser->stylist_id)->first();
                ?>
                <tr>
                    <td class="text-center"><?php echo e($i); ?></td>
                    <td><a href="javascript:void(0)"><?php echo e($stylist_data->name.' '.$stylist_data->last_name); ?></a></td>
                    <td><a href="javascript:void(0)"><?php echo e($stylist_data->email); ?></a></td>
                    <td><a href="javascript:void(0)"><?php echo e($allUser->user_name); ?></a></td>
                    <td><a href="javascript:void(0)"><?php echo e($allUser->user_email); ?></a></td>
                    <td><a href="javascript:void(0)"><?php echo e($allUser->user_phone); ?></a></td>
                    <td><a href="javascript:void(0)"><?php echo e($allUser->booking_title); ?></a></td>
                    <td><a href="javascript:void(0)"><?php echo e($allUser->booking_date); ?></a></td>
                    <td><a href="javascript:void(0)"><?php echo e($allUser->booking_time); ?></a></td>
                    <td><a href="javascript:void(0)"><?php echo e($allUser->booking_location); ?></a></td>
                    <td><a href="javascript:void(0)"><?php echo e($allUser->user_currency.' '.$allUser->user_budget); ?></a></td>
                    <td>
                        <?php if($allUser->booking_status=='0'): ?>
                        Under Discussion
                        <?php else: ?>
                        Processed
                        <?php endif; ?>
                       
                    </td>
<!--                    <td><span title="click to change status" onclick="window.location.href='<?php echo e(url('admin/update-booking-status/'.$encodedUserId)); ?>'" class="label <?php echo e($allUser->status=='1' ? 'label-success' : 'label-danger'); ?>"><?php echo e($allUser->status=='1' ? 'Click to Deactive' : 'Click to Activate'); ?></span></td>                    -->
                    <td class="text-center">
                        <div class="btn-group">
<!--                            <a href="javascript:void(0)" onclick="window.location.href='<?php echo e(url('admin/edit-terms/'.$encodedUserId)); ?>'" data-toggle="tooltip" title="Edit" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>-->
                            <a href="javascript:void(0)" onclick="window.location.href='<?php echo e(url('admin/delete-booking/'.$encodedUserId)); ?>'" data-toggle="tooltip" title="Delete" class="btn btn-xs btn-danger"><i class="fa fa-times"></i></a>
                        </div>
                    </td>
                </tr>
                 <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<!-- END Datatables Content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>