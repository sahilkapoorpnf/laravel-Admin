@extends('layouts.admin_dashboard')

@section('content')
<!-- Dashboard 2 Header -->
<div class="content-header">
    <ul class="nav-horizontal text-left">
        <li class="active">
            <a href="{{url('/admin/manage-users')}}"><i class="fa fa-user"></i> Users</a>
        </li>
        <li class="active">
            <a href="{{url('/admin/manage-users-type')}}"><i class="fa fa-user"></i> User Types</a>
        </li>

    </ul>
</div>
<!-- END Dashboard 2 Header -->
@endsection
